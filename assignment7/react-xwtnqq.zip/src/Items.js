import React from 'react';
import { useState } from 'react';

//export default makes this a public global funtion that is accessibl to all files

export default function Items(props) {
  const { src, alt, product, price } = props;

  const [count, setCount] = useState(0);

  const handleMinusClick = () => {
    if (count <= 0) {
      setCount(0);
    } else {
      setCount(count - 1);
    }
  };

  const handlePlusClick = () => {
    setCount(count + 1);
  };

  return (
    <div className="item">
      <img src={props.src} alt={props.alt} />
      <h3>{props.product}</h3>
      <p>{props.price}</p>

      <div className="pricecounter">
        <button onClick={handleMinusClick}>-</button>
        <span>{count}</span>
        <button onClick={handlePlusClick}>+</button>
      </div>
    </div>
  );
}
