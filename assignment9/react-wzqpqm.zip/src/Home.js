import React from 'react';
import './index.css';

export default function Home() {
  return (
    <div>
      <div className="header">
        <h1>In 2 Food</h1>
        <h2>
          <em>'Healing Starts from Within'</em>
        </h2>
      </div>
      <div className="imagecontainer">
        <img src="https://assets-us-01.kc-usercontent.com/ffacfe7d-10b6-0083-2632-604077fd4eca/31fc256e-801c-4068-acb7-2b93187aa37c/What-is-Nutrition-Counseling-iStock-1416417320-2023-2-TW-1024x512.jpg" />
      </div>

      <h3>Our Mission</h3>
      <div className="explanation">
        <p>
          "In 2 Food" is a website dedicated to promoting a healthy relationship
          with food and eating habits. It features a variety of easy-to-follow
          recipes, social media engagement, detailed meal plans, and scientific
          research. The site focuses on demonstrating how one can incorporate
          simple, nourishing recipes to meet their body's needs, aiming to
          support healthier lifestyle choices. The human body cannot produce
          certain essential nutrients on its own, making it necessary to obtain
          them from external sources, such as food. By consuming a variety of
          nutrient-rich foods, we provide our bodies with the vital substances
          it requires to function optimally. This intake of nutrients is key to
          helping us achieve our best physical and mental well-being.
        </p>

        <div className="imagecontainers">
          <img src="https://img.freepik.com/free-vector/spa-logo-template-health-wellness-business-branding-design-vector-wellness-text_53876-140666.jpg" />
        </div>
      </div>
    </div>
  );
}
