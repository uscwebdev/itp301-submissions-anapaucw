import React from 'react';
import './index.css';

export default function Recipes() {
  return (
    <div id="content">
      <h1>Recipes</h1>
      <p>Check out our recipes!</p>
    </div>
  );
}
