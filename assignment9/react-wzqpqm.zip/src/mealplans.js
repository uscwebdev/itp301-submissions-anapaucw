import React from 'react';
import './index.css';

export default function Mealplans() {
  return (
    <div id="content">
      <h1>Meal Plans</h1>
      <p>Find the best way of eating for you</p>
    </div>
  );
}
