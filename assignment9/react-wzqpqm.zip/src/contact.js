import React from 'react';
import './index.css';

export default function Contact() {
  return (
    <div id="content">
      <h1>Contact</h1>
      <p>Questions? Contact us!</p>
    </div>
  );
}
