import React from 'react';
import './index.css';


export default function Socialmedia() {
  return (
    <div id="content">
      <h1>Social Media</h1>
      <p>
        Find more content about this topic on tiktok, snapchat and instagram!
      </p>
    </div>
  );
}
