import React from 'react';
import './index.css';

export default function Socialmedia() {
  const image1Url = 'https://www.tiktok.com/@emthenutritionist?lang=en';
  const image2Url = 'https://www.emilyenglish.com/';
  const image3Url = 'https://www.tiktok.com/@veganexplorergirl';
  const image4Url = 'https://www.youtube.com/@VeganExplorerGirl';
  const image5Url = 'https://www.tiktok.com/@sophsplantkitchen?lang=en';
  const image6Url = 'https://www.instagram.com/sophsplantkitchen/?hl=en';

  return (
    <div id="content">
      <div className="header">
        <h1>Who to Follow</h1>
        <h2>
          <em>
            From Instagram, Youtube to Tiktok (click on the images to explore
            more about their work!)
          </em>
        </h2>
      </div>

      <div className="influencers">
        <div className="text">
          <h3
            style={{
              color: '#40531b',
              fontSize: '2em',
              marginLeft: 'auto',
              marginRight: 'auto',
              marginTop: '10px',
              width: '1050px',
            }}
          >
            Emthenutritionist
          </h3>

          <p
            style={{
              color: 'black',
              fontSize: '1.2em',
              marginLeft: 'auto',
              marginRight: 'auto',
              width: '1050px',
            }}
          >
            Emily English, known as Em the Nutritionist on TikTok, is a fully
            qualified, registered nutritionist with a degree from King's College
            London. Her interest in nutrition began at a young age, influenced
            by her family of cooks and chefs. Emily specializes in personalized
            nutrition, with a focus on DNA and gut health, and she addresses
            issues like weight loss, eating disorders, gut health, IBS,
            bloating, and energy levels.Emily is active on social media,
            particularly on TikTok, where she shares a variety of content
            related to nutrition. This includes recipes, health tips, and
            insights into her daily dietary habits as a nutritionist. Her
            approach is often described as relatable and grounded in real-world
            application, aiming to shift the perception of healthy eating away
            from a sense of sacrifice to something enjoyable and sustainable​.
          </p>
        </div>
        <div className="links">
          <div id="maincontainer" class="rows">
            <a href={image1Url} target="_blank">
              {' '}
              <img
                src="https://media.sheerluxe.com/j3Q0NfIuhE-4oe_5fkgzPcmhny4=/400x400/smart/https%3A%2F%2Fsheerluxe.com%2Fsites%2Fsheerluxe%2Ffiles%2Farticles%2F2022%2F12%2Flg-christmas-recipes-thumb.jpg?itok=vhNc7gPS"
                alt="emrecipes"
              />
            </a>
          </div>

          <div id="maincontainer1" class="rows">
            <a href={image2Url} target="_blank">
              {' '}
              <img
                src="https://static1.squarespace.com/static/5e4568acaa27976632444349/t/5eb806382ffa577e02617b0f/1634675753324/72023B7F-FC69-4BC4-A014-35ECE90B2934.jpeg?format=1500w"
                alt="aboutem"
              />
            </a>
          </div>
        </div>
      </div>

      <div className="influencers">
        <div className="text">
          <h3
            style={{
              color: '#40531b',
              fontSize: '2em',
              marginLeft: 'auto',
              marginRight: 'auto',
              marginTop: '10px',
              width: '1050px',
            }}
          >
            Veganexplorergirl
          </h3>

          <p
            style={{
              color: 'black',
              fontSize: '1.2em',
              marginLeft: 'auto',
              marginRight: 'auto',
              width: '1050px',
            }}
          >
            Amelia Sandy, known as Vegan Explorer Girl on TikTok, is a content
            creator and recipe developer who is passionate about plant-based
            cooking. She is currently studying Nutrition and uses her social
            platforms to promote food positivity, helping her followers lead a
            healthy plant-based lifestyle. Amelia is known for her nutritious
            yet delicious plant-based recipes, and she shares a range of content
            including travel experiences, snack ideas, smoothie recipes, meal
            ideas, and breakfast options on TikTok.Overall, Amelia Sandy,
            through her Vegan Explorer Girl persona, is committed to showcasing
            the wide variety of options available in plant-based eating and
            educating her audience on the benefits of a vegan lifestyle. Her
            content is a blend of culinary creativity and informative insights
            into vegan nutrition and health.
          </p>
        </div>
        <div className="links">
          <div id="maincontainer" class="rows">
            <a href={image3Url} target="_blank">
              {' '}
              <img
                src="https://i.pinimg.com/736x/30/7c/4f/307c4f319d0a9e28b2fd9ba5db68d201.jpg"
                alt="veganrecipes"
              />
            </a>
          </div>

          <div id="maincontainer1" class="rows">
            <a href={image4Url} target="_blank">
              {' '}
              <img
                src="https://i.ytimg.com/vi/eNrYg5Rubeg/hq720.jpg?sqp=-oaymwEhCK4FEIIDSFryq4qpAxMIARUAAAAAGAElAADIQj0AgKJD&rs=AOn4CLADiD1Cj8LlV07jFfM13rZl5A688w"
                alt="aboutem"
              />
            </a>
          </div>
        </div>
      </div>

      <div className="influencers">
        <div className="text">
          <h3
            style={{
              color: '#40531b',
              fontSize: '2em',
              marginLeft: 'auto',
              marginRight: 'auto',
              marginTop: '10px',
              width: '1050px',
            }}
          >
            Sophsplantkitchen
          </h3>

          <p
            style={{
              color: 'black',
              fontSize: '1.2em',
              marginLeft: 'auto',
              marginRight: 'auto',
              width: '1050px',
            }}
          >
            Sophie Waplington, known as @sophsplantkitchen on TikTok, is a
            celebrated plant-based chef, content creator, and fitness expert
            with a global influence and a significant fan base. Her TikTok
            account has over 198.8K followers and has amassed 2 million likes,
            showcasing her focus on wholesome plant-based recipes​. Sophie was
            raised as a vegetarian and transitioned to a vegan lifestyle in
            2017. Her culinary journey has included roles in social media
            marketing for a plant-based meat brand and honing her skills at a
            vegetarian restaurant in North London. She also earned her Level 3
            personal trainer certification during this time. Sophie launched
            @sophsplantkitchen in 2020 to share her innovative, protein-fueled
            recipes. This move was in response to a gap she identified in
            plant-based cooking, catering to both gym enthusiasts and
            flexitarians seeking high-protein plant-based recipes.
          </p>
        </div>
        <div className="links">
          <div id="maincontainer" class="rows">
            <a href={image5Url} target="_blank">
              {' '}
              <img
                src="https://i.pinimg.com/736x/10/94/b7/1094b74031cb92d2d19b6e9ca0aa34e0.jpg"
                alt="veganrecipes"
              />
            </a>
          </div>

          <div id="maincontainer1" class="rows">
            <a href={image6Url} target="_blank">
              {' '}
              <img
                src="https://cdn.getyourguide.com/img/tour/fc15a5a811081c95.jpeg/146.jpg"
                alt="aboutem"
              />
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}
