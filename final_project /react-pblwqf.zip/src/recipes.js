import React from 'react';
import './index.css';
import { useState } from 'react';

const API_Url = 'https://api.spoonacular.com/recipes/complexSearch';
const API_KEY = '31c696e9c6a44e6ab2ccb30038d540cd';

export default function Recipes() {
  const [query, setQuery] = useState('');
  const [recipes, setRecipes] = useState([]);

  const searchRecipes = async (title) => {
    try {
      const response = await fetch(
        `${API_Url}?query=${query}&apiKey=${API_KEY}`
      );
      const data = await response.json();
      setRecipes(data.results);
    } catch (error) {
      console.error('Error getting data', error);
    }
  };

  const handleSearch = () => {
    searchRecipes();
  };

  return (
    <div id="content">
      <h1>Recipe Inspo</h1>
      <h2>
        <em>Get some inspiration!</em>
      </h2>
      <p
        style={{
          color: '#40531b',
          fontSize: '1.3em',
          marginLeft: 'auto',
          marginRight: 'auto',
          marginTop: '0px',
          marginBottom: '10px',
          width: '700px',
        }}
      >
        Finding the right meal to cook can often be a daunting task, especially
        when you're unsure of what you're in the mood to eat. To make this
        process easier and more enjoyable, consider diving into an array of
        mouth-watering recipes. Whether you're craving something savory or
        sweet, light or hearty, there's a recipe out there to satisfy your taste
        buds. Let your taste preferences guide you to the perfect recipe for
        today's meal and you can add your own personal twist ☀︎
      </p>
      <label style={{ margin: '10px', color: '#011936' }}>
        Find a Recipe:{' '}
      </label>
      <input
        type="text"
        value={query}
        onChange={(e) => setQuery(e.target.value)}
        placeholder="Search...."
      />
      <div>
        <button
          style={{ margin: '10px', backgroundColor: '#40531b', color: 'white' }}
          onClick={handleSearch}
        >
          Search
        </button>
        {recipes.map((recipe) => (
          <div key={recipe.id}>
            <h3
              style={{
                color: '#40531b',
                fontSize: '1.5em',
                marginLeft: 'auto',
                marginRight: 'auto',
                marginTop: '5px',
                marginBottom: '0px',
                width: '1400px',
              }}
            >
              {recipe.title}
            </h3>
            <img
              src={recipe.image}
              alt={recipe.title}
              style={{
                marginLeft: '30px',
                marginTop: '5px',
                width: '350px',
              }}
            />
          </div>
        ))}
      </div>
    </div>
  );
}
