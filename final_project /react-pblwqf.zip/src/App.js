import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Navbar from './navbar';
import Recipes from './recipes';
import Socialmedia from './socialmedia';
import Contact from './contact';
import Home from './Home';

function App() {
  return (
    <>
      <Router>
        <Navbar />
        <div id="content">
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="*" element={<Home />} />
            <Route path="/recipes" element={<Recipes />} />
            <Route path="/socialmedia" element={<Socialmedia />} />
            <Route path="/contact" element={<Contact />} />
          </Routes>
        </div>
      </Router>
    </>
  );
}

export default App;
