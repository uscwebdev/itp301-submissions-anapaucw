import React from 'react';
import './index.css';
import { useState } from 'react';
import './contact.css';

export default function Contact() {
  const [fullname, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [comment, setComment] = useState('');
  const [confirmation, setConfirmation] = useState(false);

  const [, setFullNameError] = useState();
  const [, setEmailError] = useState();
  const [, setCommentError] = useState();
  const [, setTermsError] = useState();

  function handleOnChange(e) {
    console.log(e.target.value);
    console.log(e.currentTarget.value);

    const { name, value, checked } = e.target;

    switch (name) {
      case 'fullname':
        setFullName(value);
        break;
      case 'email':
        setEmail(value);
        break;
      case 'phone':
        setPhone(value);
        break;
      case 'comment':
        setComment(value);
        break;
      case 'confirmation':
        setConfirmation(checked);
        break;
      default:
        break;
    }
  }

  function handleSubmit(e) {
    e.preventDefault();
    let foundError = false;
    let errorMessages = [];
    let count = 0;

    for (let i = 0; i < fullname.length; i++) {
      if (fullname[i] == ' ') {
        count++;
      }
    }
    if (fullname.length == 0) {
      foundError = true;
      errorMessages.push('Name cannot be empty');
    } else if (count == 0) {
      foundError = true;
      errorMessages.push('Must provide a full name');
    } else {
      setFullNameError('');
    }

    //email & password
    if (!email && !phone) {
      foundError = true;
      errorMessages.push('Must provide either a phone or an email');
    } else {
      setEmailError('');
    }

    //comments count
    if (comment.length > 100) {
      foundError = true;
      errorMessages.push('Comments cannot exceed 100 characters.');
    } else {
      setCommentError('');
    }

    //confirmation
    if (!confirmation) {
      foundError = true;
      errorMessages.push('You must accept follow up confirmation.');
    } else {
      setTermsError('');
    }

    if (foundError) {
      alert(errorMessages.join('\n'));
    } else {
      alert('Comment was succesfully sent');
    }
  }

  return (
    <div id="container">
      <h1>Get in Touch :) </h1>
      <h2>
        <em>Any Questions? Comments? Concerns?</em>
      </h2>

      <div id="box">
        <div className="row">
          <div className="col">
            <form onSubmit={handleSubmit}>
              <div className="fullname">
                <label htmlFor="full-name" className="col-sm-2 col-form-label">
                  Full Name: <span>*</span>
                </label>
                <div className="textbox">
                  <input
                    type="text"
                    className="form-control"
                    placeholder="Ana Paula Cedillo"
                    id="full-name"
                    name="fullname"
                    value={fullname}
                    onChange={(e) => {
                      setFullName(e.currentTarget.value);
                    }}
                  />
                </div>
              </div>

              <div className="row">
                <label className="col">
                  Provide One: <span>*</span>
                </label>
                <div className="col-10">
                  <div className="row">
                    <label htmlFor="email" className="col-sm-2 col-form-label">
                      Email:
                    </label>
                    <div className="emailbox">
                      <input
                        type="text"
                        className="form-control"
                        placeholder="anapauce@usc.edu"
                        id="email"
                        name="email"
                        value={email}
                        onChange={(e) => {
                          setEmail(e.currentTarget.value);
                        }}
                      />
                    </div>

                    <label
                      htmlFor="phone"
                      className="mt-sm-2 col-sm-2 col-form-label"
                    >
                      Phone:
                    </label>
                    <div className="phonebox">
                      <input
                        type="text"
                        className="form-control"
                        placeholder="(936) 242 1471"
                        id="phone"
                        name="phone"
                        value={phone}
                        onChange={(e) => {
                          setPhone(e.currentTarget.value);
                        }}
                      />
                    </div>
                  </div>
                </div>
              </div>

              <div className="row">
                <label htmlFor="comment">Questions/Comments:</label>
                <div className="col">
                  <textarea
                    className="form-control"
                    id="comment"
                    name="comment"
                    value={comment}
                    onChange={(e) => {
                      setComment(e.currentTarget.value);
                    }}
                  ></textarea>

                  <small id="comment-count">{comment.length} / 100</small>
                </div>
              </div>

              <div className="row">
                <label></label>
                <div className="col">
                  <div className="form-check form-check-inline">
                    <input
                      className="form-check-input"
                      type="checkbox"
                      id="terms"
                      name="confirmation"
                      checked={confirmation}
                      onChange={(e) => {
                        setConfirmation(!confirmation);
                      }}
                    />
                    <label className="labelcheck" htmlFor="terms">
                      I accept to have my responsed emailed.
                      <span>*</span>
                    </label>
                  </div>
                </div>
              </div>
              <div className="row">
                <div className="col">
                  <button type="submit" className="btn">
                    Submit
                  </button>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
}
