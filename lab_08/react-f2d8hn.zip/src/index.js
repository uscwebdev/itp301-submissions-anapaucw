import React from 'react';
import { createRoot } from 'react-dom/client';

import Items from './Items.js';
import './index.css';

const root = createRoot(document.querySelector('#root'));

root.render(
  <React.StrictMode>
    <div id="header">
      <h1>My Closet Wish List</h1>
    </div>

    <Items />

    <div id="footer">
      <p>
        <em>University of Southern California ©2023</em>
      </p>
    </div>
  </React.StrictMode>
);
