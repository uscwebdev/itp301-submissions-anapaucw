import React from 'react';
import { useState } from 'react';

//export default makes this a public global funtion that is accessibl to all files

export default function Items() {
  const [subtotal, setSubtotal] = useState(0);

  function handleIncreaseAmount(price) {
    price = parseInt(price);
    setSubtotal(subtotal + price);
  }

  function handleDecreaseAmount(price) {
    price = parseInt(price);
    setSubtotal(subtotal - price);
  }

  return (
    <div id="content">
      <Cart
        imgsrc="https://astaresort.com/cdn/shop/files/MICH172-174_800x.jpg?v=1688721753"
        alttext="cami"
        product="Carolina Camisole - ROSSA Sequin"
        price="150.00"
        handleDecrease={handleDecreaseAmount}
        handleIncrease={handleIncreaseAmount}
      />

      <Cart
        imgsrc="https://cdn.shopify.com/s/files/1/2328/9949/files/000014520029_5_1600x.jpg?v=1696055144"
        alttext="skirt"
        product="CROCHET PLEAT MINI SKIRT - MOSS"
        price="79.00"
        handleDecrease={handleDecreaseAmount}
        handleIncrease={handleIncreaseAmount}
      />

      <Cart
        imgsrc="https://i.pinimg.com/736x/89/48/67/894867e49fb621d91791abecf130ea22.jpg"
        alttext="boots"
        product="ROCKY Brown Distressed"
        price="189.00"
        handleDecrease={handleDecreaseAmount}
        handleIncrease={handleIncreaseAmount}
      />

      <Cart
        imgsrc="https://mas1brand.com/cdn/shop/files/IMG_9060.jpg?v=1696592399"
        alttext="bag"
        product="CH STEEL+ BEIGE INNER BAG + METAL CHAIN"
        price="120.00"
        handleDecrease={handleDecreaseAmount}
        handleIncrease={handleIncreaseAmount}
      />
      <h4>Subtotal: ${subtotal}</h4>
    </div>
  );
}

function Cart(props) {
  const [count, setCount] = useState(0);

  return (
    <div className="content">
      <img src={props.imgsrc} alt={props.alttext} />
      <h3>{props.product}</h3>
      <p>
        $<span>{props.price}</span>
      </p>

      <div className="count">
        <button
          id="minus"
          onClick={() => {
            props.handleDecrease(props.price);
            handleMinusClick(props.count);
          }}
        >
          -
        </button>
        <div id="items-count">{count}</div>
        <button
          id="plus"
          onClick={() => {
            props.handleIncrease(props.price);
            handlePlusClick(props.count);
          }}
        >
          +
        </button>
      </div>
    </div>
  );

  function handleMinusClick() {
    if (count > 0) {
      setCount(count - 1);
    }
  }

  function handlePlusClick() {
    setCount(count + 1);
  }
}
