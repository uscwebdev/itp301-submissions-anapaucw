import React from 'react';
import { useState } from 'react';

export default function ImgSwitch() {
  const [src, setSrc] = useState(
    'https://hips.hearstapps.com/hmg-prod/images/delish-202002-pozole-0392-landscape-pf-1582315071.jpg?crop=0.888421052631579xw:1xh;center,top&resize=1200:*'
  );

  const [alt, setAlt] = useState('Pozole');
  const [cap, setCaption] = useState('Pozole');

  function handleImageChange(newSrc, newAlt, newCap) {
    console.log('changing the image');
    setSrc(newSrc);
    setAlt(newAlt);
    setCaption(newCap);
  }

  return (
    <div id="content">
      <h3>Click on the buttons to view photos</h3>
      <img id="mexdishes" src={src} alt={alt} />
      <p>{cap}</p>
      <div id="buttons">
        <button
          onClick={() => {
            handleImageChange(
              'https://hips.hearstapps.com/hmg-prod/images/delish-202002-pozole-0392-landscape-pf-1582315071.jpg?crop=0.888421052631579xw:1xh;center,top&resize=1200:*',
              'Pozole',
              'Pozole'
            );
          }}
        >
          Pozole
        </button>
        <button
          onClick={() => {
            handleImageChange(
              'https://www.washingtonpost.com/resizer/8nYZg5R8H3g_HzGxjL9bAJvq4hg=/arc-anglerfish-washpost-prod-washpost/public/AMMZ5EBDWYI63JZPDZYUSBZPXQ.jpg',
              'Chiles',
              'Chiles en Nogada'
            );
          }}
        >
          Chiles en Nogada
        </button>
        <button
          onClick={() => {
            handleImageChange(
              'https://static01.nyt.com/images/2019/06/12/dining/10Tajinrex/merlin_156061500_17b2227d-01f8-4839-b8ae-1970228d6b7c-articleLarge.jpg',
              'Mangonada',
              'Mangonada'
            );
          }}
        >
          Mangonada
        </button>
        <button
          onClick={() => {
            handleImageChange(
              'https://www.caciquefoods.com/wp-content/uploads/2016/05/Enmoladas-1.jpg',
              'Enmoladas',
              'Enmoladas'
            );
          }}
        >
          Enmoladas
        </button>
        <button
          onClick={() => {
            handleImageChange(
              'https://www.allrecipes.com/thmb/sYbmpNZhPVYvQA2yUWqjx1q42T0=/1500x0/filters:no_upscale():max_bytes(150000):strip_icc()/65338-Birria-de-Res-Tacos-ddmfs-4x3-2563-ca793a7c87c54af5ab600fd463ba2467.jpg',
              'Tacos',
              'Tacos de Birria'
            );
          }}
        >
          Tacos de Birria
        </button>
      </div>
    </div>
  );
}
