import React from 'react';

//export default makes this a public global funtion that is accessibl to all files

export default function Comments(props) {
  const { src, alt, username, postdate, comment } = props;
  return (
    <div class="usercomment">
      <img src={props.src} alt={props.alt} />
      <h3>{props.username}</h3>
      <h4>{props.postdate}</h4>
      <p>{props.comment}</p>
    </div>
  );
}
