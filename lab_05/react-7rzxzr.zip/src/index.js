import React from 'react';
import { createRoot } from 'react-dom/client';
import './index.css';

const root = createRoot(document.querySelector('#root'));

root.render(
  <React.StrictMode>
    <h1>Ana Pau Cedillo</h1>
    <h2>
      <a href="mailto:anapauce@usc.edu">anapauce@usc.edu</a>
    </h2>

    <div id="box">
      <h3>Favorite Color</h3>
      <p className="color">Dark Green</p>

      <h3>Favorite Website</h3>
      <p>
        One of my favorite websites is the{' '}
        <a href="https://www.freepeople.com/" target="_blank">
          Free People
        </a>{' '}
        online store. I can't afford anything from there but I love window
        shopping!
      </p>
      <h3>My Favorite Activity</h3>
      <p>
        During my free time, whenever I have time, I enjoy being outdoors,
        hiking and enjoying nature as much as possible.
      </p>
      <img
        src="https://i0.wp.com/images-prod.healthline.com/hlcmsresource/images/topic_centers/2019-8/couple-hiking-mountain-climbing-1296x728-header.jpg?w=1155&h=1528"
        alt="hiking"
      />

      <h3>My Classes Enrolled</h3>
      <ul>
        <li>ECON317</li>
        <li>ECON303</li>
        <li>ITP301</li>
        <li>RELI46</li>
      </ul>
    </div>
  </React.StrictMode>
);
