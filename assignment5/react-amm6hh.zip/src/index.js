import React from 'react';
import { createRoot } from 'react-dom/client';
import './index.css';

const root = createRoot(document.querySelector('#root'));

root.render(
  <React.StrictMode>
    <div id="box">
      <h1>Best Movies of ALL Time</h1>

      <h2>Shrek 2</h2>
      <p>
        Making a sequel that lives up to the original is a hard task for any
        filmmaker, and so often they fail in comparison. There are a few
        examples of sequels being as good or better than their predecessors,
        like The Dark Knight and Toy Story 2, but good sequels are kind of few
        and far between for a reason. A good sequel has to be more than just a
        good movie on its own. A good sequel needs to expand on the world and
        the story established in the first film. They also need to use the
        characters in a way that further develops them, while staying true to
        what audiences already know.In the case of Shrek 2, the film pulled off
        what the best sequels manage to do: up the stakes both emotionally and
        physically, build on the established world, and offer a more complicated
        story that provides a twist on everything that made the first film work.
        If you aren't convinced yet, please do yourself a favor and watch{' '}
        <a href="https://www.youtube.com/watch?v=A_HjMIjzyMU" target="_blank">
          this scene
        </a>
        . Your life will be changed.
      </p>
      <img
        src="https://static1.colliderimages.com/wordpress/wp-content/uploads/2022/03/Shrek-2.jpg"
        alt="shrek"
      />

      <h2>Pride and Prejudice (2005)</h2>
      <p>
        At the heart of Pride & Prejudice was the stellar performances given by
        Knightley and Macfadyen. Aside from the chemistry they brought to their
        characters, they also gave incredibly nuanced accounts individually,
        that helped to elevate their respective narrative arcs and give more
        breadth Austen's story. Beyond the initial foundation that makes 2005's
        Pride & Prejudice a success, some significant scenes and elements often
        give audiences feel-good feelings after watching it. From start to
        finish, the film is beautiful, with a fantastic soundtrack and
        compelling storyline that created life-long fans from its initial
        release.
      </p>
      <img
        src="https://ntvb.tmsimg.com/assets/p159494_v_h8_ad.jpg?w=1280&h=720"
        alt="pride"
      />

      <h2>Back to the Future</h2>
      <p>
        A movie I consider literally perfect. Tell me about its imperfections.
        Point out to me its plot holes. Lecture me on how time travel doesn't
        work like that. I don't care. It's a weird little science-fiction incest
        comedy that, to me, sets the standard all other popcorn movies must
        match, the one that leaves them all feeling a little bit lacking.From
        start to finish, Bob Gale and Robert Zemeckis's Oscar-nominated
        screenplay is a marvel. Its structure is an elaborately constructed
        concoction that winds itself as tight as it possibly can in its first
        half, then unleashes all of that pent-up energy in a second half that
        never once pauses for breath yet still manages to cram in a full musical
        sequence.The Back To The Future screenplay is brilliantly written. For
        such a seemingly lighthearted film, it touches upon serious topics. A
        must watch for sure.
      </p>
      <img
        src="https://ntvb.tmsimg.com/assets/p8717_v_h8_ai.jpg?w=960&h=540"
        alt="future"
      />
    </div>
    <h2 className="comments">Comments</h2>
    <Thumbnail />
    <Thumbnail />
    <Thumbnail />
    <Thumbnail />
  </React.StrictMode>
);

function Thumbnail() {
  return (
    <div className="thumbnail">
      <img
        src="https://img.freepik.com/premium-vector/account-icon-user-icon-vector-graphics_292645-552.jpg?w=2000"
        alt="USC Logo"
      />
      <h4>Userurmom299328</h4>
      <p>I believe that this list is astronomically atrocious. </p>
      <p>August 29, 2023</p>
    </div>
  );
}
