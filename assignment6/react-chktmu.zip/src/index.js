import React from 'react';
import { createRoot } from 'react-dom/client';
import Items from './Items.js';
import './index.css';

const root = createRoot(document.querySelector('#root'));

root.render(
  <React.StrictMode>
    <div id="header">
      <h1>My Closet Wish List</h1>
    </div>

    <div className="items1">
      <Items
        src="https://astaresort.com/cdn/shop/files/MICH172-174_800x.jpg?v=1688721753"
        alt="cami"
        product="Carolina Camisole - ROSSA Sequin"
        price="$150.99"
      />

      <Items
        src="https://cdn.shopify.com/s/files/1/2328/9949/files/000014520029_5_1600x.jpg?v=1696055144"
        alt="skirt"
        product="CROCHET PLEAT MINI SKIRT - MOSS"
        price="$79.00"
      />
    </div>

    <div className="items2">
      <Items
        src="https://i.pinimg.com/736x/89/48/67/894867e49fb621d91791abecf130ea22.jpg"
        alt="boots"
        product="ROCKY Brown Distressed"
        price="$189.95"
      />

      <Items
        src="https://mas1brand.com/cdn/shop/products/IMG_6117.jpg?v=1694513259&width=700"
        alt="bag"
        product="CH STEEL+ BEIGE INNER BAG + METAL CHAIN"
        price="$120.00"
      />
    </div>

    <div id="footer">
      <p>University of Southern California ©2023</p>
    </div>
  </React.StrictMode>
);
