import React from 'react';

//export default makes this a public global funtion that is accessibl to all files

export default function Items(props) {
  const { src, alt, product, price } = props;
  return (
    <div class="item">
      <img src={props.src} alt={props.alt} />
      <h3>{props.product}</h3>
      <p>{props.price}</p>
    </div>
  );
}
